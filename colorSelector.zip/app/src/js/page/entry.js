// 样式
require('../../css/style.less');

// 页面组件
require('./index');
